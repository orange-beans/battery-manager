'use strict';
/* 渲染层逻辑：仪表盘 + 设置页 */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

let currentSettings = null;
let configPath = '';
let lastState = null; // 最近一次电池状态（切换模式后用于立即重渲染）

/** 读取当前电池模式 */
function isSingleMode() {
  return currentSettings && currentSettings.batteryMode === 'single';
}

/** 按电池模式调整界面结构（卡片数量、标题、B 相关项显隐） */
function applyModeUI() {
  const single = isSingleMode();
  $('.cards').classList.toggle('single', single);
  $('#card-B').classList.toggle('hidden', single);
  $('#card-A .card-head h2').textContent = single ? '电池' : '电池 A';
  $('#row-offset-b').classList.toggle('hidden', single);
}

/** 版本号展示（主界面底部 + 设置页底部） */
function renderVersion(v) {
  $('#foot-version').textContent = v ? `V${v}` : '';
  $('#settings-version').textContent = v ? `电池状态监控 V${v}` : '';
}

// ---------- 视图切换 ----------
function showView(name) {
  $('#view-dashboard').classList.toggle('hidden', name !== 'dashboard');
  $('#view-settings').classList.toggle('hidden', name !== 'settings');
  if (name === 'settings') loadSettingsIntoForm();
}

// ---------- Toast ----------
let toastTimer = null;
function toast(msg, isError = false) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.toggle('error', isError);
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2400);
}

// ---------- 仪表盘渲染 ----------
function socClass(soc, low) {
  if (low || soc <= 20) return 'red';
  if (soc <= 50) return 'amber';
  return '';
}

function renderBattery(key, bat, single = false) {
  const card = $(`#card-${key}`);
  if (!bat) {
    $('[data-role="fill"]', card).style.width = '0%';
    $('[data-role="soc"]', card).textContent = '--%';
    $('[data-role="voltage"]', card).textContent = '--';
    $('[data-role="soc2"]', card).textContent = '--';
    const st = $('[data-role="status"]', card);
    st.textContent = '--';
    st.className = 'stat-value';
    ['running', 'low', 'voltwarn'].forEach((r) => $(`[data-role="${r}"]`, card).classList.add('hidden'));
    card.classList.remove('low');
    return;
  }

  const fill = $('[data-role="fill"]', card);
  fill.style.width = `${Math.max(0, Math.min(100, bat.soc))}%`;
  fill.className = `battery-fill ${socClass(bat.soc, bat.low)}`.trim();

  $('[data-role="soc"]', card).textContent = `${bat.soc}%`;

  const voltEl = $('[data-role="voltage"]', card);
  voltEl.textContent = `${bat.voltage.toFixed(2)} V`;
  voltEl.className = `stat-value ${bat.voltageWarn ? 'text-amber' : ''}`.trim();

  const soc2 = $('[data-role="soc2"]', card);
  soc2.textContent = `${bat.soc}%`; // 与电池壳内电量格式一致
  soc2.className = `stat-value ${bat.low ? 'text-red' : bat.soc <= 50 ? 'text-amber' : 'text-green'}`;

  const st = $('[data-role="status"]', card);
  if (bat.low) {
    st.textContent = '需充电';
    st.className = 'stat-value text-red';
  } else if (single) {
    // 单电池模式：running 无意义，仅区分正常/需充电
    st.textContent = '正常';
    st.className = 'stat-value text-green';
  } else if (bat.running) {
    st.textContent = '运行中';
    st.className = 'stat-value text-blue';
  } else {
    st.textContent = '待机';
    st.className = 'stat-value';
  }

  $('[data-role="running"]', card).classList.toggle('hidden', single || !bat.running);
  $('[data-role="low"]', card).classList.toggle('hidden', !bat.low);
  $('[data-role="voltwarn"]', card).classList.toggle('hidden', !bat.voltageWarn || bat.voltage === 0);
  card.classList.toggle('low', bat.low);
}

function renderState(state) {
  lastState = state;
  applyModeUI();
  const single = isSingleMode();
  const pill = $('#conn-pill');
  const connText = $('#conn-text');
  const banner = $('#error-banner');

  if (state.connected) {
    pill.className = 'conn-pill connected';
    connText.textContent = '已连接';
    banner.classList.add('hidden');
  } else {
    pill.className = 'conn-pill disconnected';
    connText.textContent = '未连接';
    banner.textContent = state.error ? `连接异常：${state.error}` : '连接异常';
    banner.classList.remove('hidden');
  }

  renderBattery('A', state.A, single);
  if (!single) renderBattery('B', state.B);

  $('#meta-device').textContent = state.connected
    ? `设备ID ${state.deviceId} · 固件 ${state.firmware}`
    : '';
  $('#meta-update').textContent = state.lastOk
    ? `最后更新 ${new Date(state.lastOk).toLocaleTimeString('zh-CN', { hour12: false })}`
    : '';
  // 仅连接时显示 ADC 调试信息（靠右，格式统一）；单电池模式只显示 A
  $('#foot-adc').textContent = state.connected
    ? single
      ? `ADC（调试）  A: ${state.adcA}`
      : `ADC（调试）  A: ${state.adcA}   B: ${state.adcB}`
    : '';
}

// ---------- 设置页 ----------
async function refreshPorts(prefer) {
  const sel = $('#set-port');
  const ports = await window.api.listPorts();
  sel.innerHTML = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = ports.length ? '— 请选择 —' : '（未检测到串口）';
  sel.appendChild(empty);
  for (const p of ports) {
    const opt = document.createElement('option');
    opt.value = p.path;
    opt.textContent = p.description ? `${p.path}（${p.description}）` : p.path;
    sel.appendChild(opt);
  }
  // 如果保存的端口当前不存在，也保留显示，便于用户感知
  if (prefer && !ports.some((p) => p.path === prefer)) {
    const opt = document.createElement('option');
    opt.value = prefer;
    opt.textContent = `${prefer}（当前未连接）`;
    sel.appendChild(opt);
  }
  sel.value = prefer || '';
}

async function loadSettingsIntoForm() {
  const { settings, configPath: cp } = await window.api.getState();
  currentSettings = settings;
  configPath = cp;
  $('#config-path').textContent = cp;
  $('#set-interval').value = settings.pollIntervalSec;
  $('#interval-val').textContent = `每 ${settings.pollIntervalSec} 秒 1 次`;
  $('#set-autostart').checked = settings.autoStart;
  $('#set-slave').value = settings.slaveAddress;
  $('#set-lowth').value = settings.lowBatteryThreshold;
  $('#set-lowalert').checked = settings.lowAlertEnabled;
  $('#set-lowalert-interval').value = settings.lowAlertIntervalMin;
  $('#set-lowalert-interval').disabled = !settings.lowAlertEnabled;
  $('#set-mode').value = settings.batteryMode;
  $('#set-api-enabled').checked = settings.apiEnabled;
  $('#set-api-port').value = settings.apiPort;
  $('#set-api-port').disabled = !settings.apiEnabled;
  await refreshPorts(settings.port);
  refreshOffsets(true); // 打开设置页自动读取硬件偏移（静默）
  applyModeUI();
}

async function saveSettings() {
  const apiPort = Number($('#set-api-port').value);
  if (!Number.isInteger(apiPort) || apiPort < 1024 || apiPort > 65535) {
    toast('状态接口端口需为 1024 ~ 65535 的整数', true);
    return;
  }
  const newSettings = {
    ...currentSettings,
    port: $('#set-port').value,
    pollIntervalSec: Number($('#set-interval').value),
    autoStart: $('#set-autostart').checked,
    batteryMode: $('#set-mode').value,
    slaveAddress: Number($('#set-slave').value),
    lowBatteryThreshold: Number($('#set-lowth').value),
    lowAlertEnabled: $('#set-lowalert').checked,
    lowAlertIntervalMin: Number($('#set-lowalert-interval').value),
    apiEnabled: $('#set-api-enabled').checked,
    apiPort,
  };
  const res = await window.api.saveSettings(newSettings);
  if (res.ok) {
    currentSettings = res.settings;
    applyModeUI();
    if (lastState) renderState(lastState); // 模式变化后按新布局立即重渲染
    toast('设置已保存并生效');
  } else {
    toast(`保存失败：${res.error}`, true);
  }
}

// ---------- 硬件偏移量 ----------
async function refreshOffsets(silent = false) {
  const res = await window.api.readOffsets();
  const status = $('#offset-status');
  if (res.ok) {
    $('#set-offset-a').value = res.A;
    $('#set-offset-b').value = res.B;
    status.textContent = `当前硬件偏移：A=${res.A}mV  B=${res.B}mV`;
  } else {
    status.textContent = res.error;
    if (!silent) toast(res.error, true);
  }
}

async function writeOffset(battery, btn) {
  const input = $(`#set-offset-${battery.toLowerCase()}`);
  const raw = input.value.trim();
  const val = Number(raw);
  if (raw === '' || !Number.isFinite(val) || val < -1000 || val > 1000) {
    toast(`请输入 -1000 ~ 1000 之间的整数（当前：${raw || '空'}）`, true);
    return;
  }
  btn.disabled = true;
  try {
    const res = await window.api.writeOffset(battery, val);
    const status = $('#offset-status');
    if (res.ok) {
      $('#set-offset-a').value = res.A;
      $('#set-offset-b').value = res.B;
      status.textContent = `写入成功，已读回确认：A=${res.A}mV  B=${res.B}mV`;
      toast(`电池${battery}偏移已写入设备`);
    } else {
      status.textContent = res.error;
      toast(res.error, true);
    }
  } finally {
    btn.disabled = false;
  }
}

// ---------- 初始化 ----------
window.addEventListener('DOMContentLoaded', async () => {
  // 标题栏按钮：最小化/关闭均退回托盘
  $('#btn-min').addEventListener('click', () => window.api.hideWindow());
  $('#btn-close').addEventListener('click', () => window.api.hideWindow());

  // 视图切换
  $('#btn-goto-settings').addEventListener('click', () => showView('settings'));
  $('#btn-back').addEventListener('click', () => showView('dashboard'));

  // 设置页交互
  $('#set-interval').addEventListener('input', (e) => {
    $('#interval-val').textContent = `每 ${e.target.value} 秒 1 次`;
  });
  $('#set-lowalert').addEventListener('change', (e) => {
    $('#set-lowalert-interval').disabled = !e.target.checked;
  });
  $('#set-api-enabled').addEventListener('change', (e) => {
    $('#set-api-port').disabled = !e.target.checked;
  });
  $('#btn-read-offset').addEventListener('click', () => refreshOffsets(false));
  $('#btn-write-offset-a').addEventListener('click', (e) => writeOffset('A', e.currentTarget));
  $('#btn-write-offset-b').addEventListener('click', (e) => writeOffset('B', e.currentTarget));
  $('#btn-refresh-ports').addEventListener('click', () => refreshPorts($('#set-port').value));
  $('#btn-save').addEventListener('click', saveSettings);
  $('#btn-reset').addEventListener('click', async () => {
    await window.api.saveSettings({}); // 空对象 → 主进程清洗为默认值
    await loadSettingsIntoForm();
    toast('已恢复默认设置');
  });
  $('#btn-open-config').addEventListener('click', () => window.api.openConfigFolder());

  // 托盘菜单跳转（如点“设置”）
  window.api.onNavShow((view) => showView(view === 'settings' ? 'settings' : 'dashboard'));

  // 电池状态推送
  window.api.onBatteryUpdate(renderState);

  // 首次加载
  const { settings, configPath: cp, state, version } = await window.api.getState();
  currentSettings = settings;
  configPath = cp;
  renderVersion(version);
  renderState(state);
});
